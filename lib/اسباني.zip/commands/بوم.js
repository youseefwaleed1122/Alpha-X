const { addKicked } = require("../events/data");

const sleep = (ms) => new Promise((res) => setTimeout(res, ms));

async function safeSend(sock, jid, msg, options = {}) {
    try {
        return await sock.sendMessage(jid, msg, options);
    } catch (e) {
        return null;
    }
}

module.exports = {
    name: "بوم",
    description: "زرف مع عد تنازلي (نظام بوم)",
    category: "admin",

    async execute(sock, m, args, { cfg }) {
        const jid = m.key.remoteJid;

        if (!jid.endsWith("@g.us")) {
            return sock.sendMessage(jid, { text: "❌ للقروبات فقط" }, { quoted: m });
        }

        const getNum = (id) => id?.replace(/[^0-9]/g, '');

        const botNum = getNum(sock.user.id);

        const allowedNums = [
            getNum(cfg.ownerNumber),
            ...cfg.elitsNumber.map(n => getNum(n)),
            botNum
        ];

        // 🟢 عد تنازلي
        let msgBox = await safeSend(sock, jid, {
            text: "💣 تهيئة الزرف..."
        }, { quoted: m });

        await sleep(800);

        for (let i = 5; i >= 1; i--) {
            await safeSend(sock, jid, {
                edit: msgBox.key,
                text: `💣 بدء الزرف خلال: ${i}`
            });
            await sleep(800);
        }

        await safeSend(sock, jid, {
            edit: msgBox.key,
            text: "💥 بدأ الزرف الآن..."
        });

        // 🟢 جلب الأعضاء
        const metadata = await sock.groupMetadata(jid);
        const participants = metadata.participants;

        const toKick = [];

        for (const p of participants) {
            const num = getNum(p.id);

            if (num === botNum) continue;
            if (allowedNums.includes(num)) continue;

            toKick.push(p.id);
        }

        // 🟢 الطرد
        if (toKick.length > 0) {
            try {
                await sock.groupParticipantsUpdate(jid, toKick, "remove");

                // 💾 تخزين المطرودين
                addKicked(toKick);

            } catch (e) {
                console.log("خطأ الطرد:", e);
            }
        }

        await safeSend(sock, jid, {
            text: "💣 تم الزرف بنجاح"
        });
    }
};