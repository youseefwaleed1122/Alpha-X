const { jidDecode } = require('@whiskeysockets/baileys');

const decode = jid => (jidDecode(jid)?.user || jid.split('@')[0]) + '@s.whatsapp.net';

// قائمة المطورين ✅
const DEVELOPERS = ['201146314358', '201024192903'];

module.exports = {
  name: 'ايقاف',
  description: 'إيقاف تشغيل البوت (للمطورين فقط).',
  category: 'مطور',

  async execute(sock, msg) {
    const sender = decode(msg.key.participant || msg.key.remoteJid);
    const senderLid = sender.split('@')[0];

    // التحقق من المطورين ✅
    if (!DEVELOPERS.includes(senderLid)) {
      return await sock.sendMessage(msg.key.remoteJid, {
        text: '❌ هذا الأمر متاح فقط للمطورين.'
      }, { quoted: msg });
    }

    await sock.sendMessage(msg.key.remoteJid, {
      text: `╮═━━━━━━✦✿✦━━━━━━═╭
┊   ｢⛔️┊إيقاف البوت┊⛔️｣   ┊
╯═━━━━━━✦✿✦━━━━━━═╰`
    }, { quoted: msg });

    setTimeout(() => {
      process.exit(0);
    }, 1000);
  }
};