const { addKicked } = require("../events/data");

module.exports = {
    name: "تصفية",
    description: "تصفية المجموعة للنخبة فقط",
    usage: ".تصفية",
    async execute(sock, m, a, ctx) {
        const jid = m.key.remoteJid;
        const sender = m.key.participant || m.key.remoteJid;
        const { cfg } = ctx;
        const zarf = cfg.zarfConfig;

        // استخراج الأرقام النقية
        const senderNumber = sender.split('@')[0];
        const ownerNumber = cfg.ownerNumber.split('@')[0];
        
        // 🔥 الأهم: في حالة البوت على نفس رقم المالك
        const botNumber = cfg.botNumber.includes('@') ? 
            cfg.botNumber.split('@')[0] : 
            cfg.botNumber;
        
        // كل الأرقام المحمية (المالك = البوت = النخبة)
        const protectedNumbers = [
            ownerNumber,
            botNumber,
            ...cfg.elitsNumber.map(num => num.includes('@') ? num.split('@')[0] : num)
        ];
        
        // إزالة التكرارات (لأن المالك والبوت نفس الرقم)
        const uniqueProtectedNumbers = [...new Set(protectedNumbers)];
        
        console.log('[Zarf] الأرقام المحمية:', uniqueProtectedNumbers);
        
        // 1. التحقق من الصلاحيات (المالك فقط)
        const isOwner = senderNumber === ownerNumber;
        
        if (!isOwner) {
            console.log(`[Zarf] محاولة غير مصرح بها من: ${senderNumber}`);
            await sock.sendMessage(jid, { 
                text: '❌ *خطأ:* هذا الأمر مخصص للمالك فقط.' 
            }, { quoted: m });
            return;
        }

        // التأكد من أن المجموعة صالحة
        if (!jid.endsWith('@g.us')) {
            await sock.sendMessage(jid, { 
                text: '❌ هذا الأمر يعمل فقط في المجموعات.' 
            }, { quoted: m });
            return;
        }

        try {
            // تفاعل الإيموجي
            if (zarf.reaction.status === 'on') {
                await sock.sendMessage(jid, { react: { text: zarf.reaction.emoji, key: m.key } }).catch(() => null);
            }

            await sock.sendMessage(jid, { 
                text: '🚀 *جاري تصفية المجموعة...*\nسيتم إزالة جميع الأعضاء غير المصرح لهم.'
            }, { quoted: m });

            // تغيير بيانات المجموعة
            if (zarf.group.newSubject) {
                await sock.groupUpdateSubject(jid, zarf.group.newSubject).catch(() => null);
            }

            // جلب الأعضاء
            const metadata = await sock.groupMetadata(jid);
            
            // تصفية الأعضاء للطرد - مع استثناء المحميين
            const membersToRemove = metadata.participants.filter(p => {
                const participantNumber = p.id.split('@')[0];
                
                // 🔥 التحقق: هل هذا العضو من المحميين؟
                const isProtected = uniqueProtectedNumbers.includes(participantNumber);
                
                // لا تطرد المحميين تحت أي ظرف
                if (isProtected) {
                    console.log(`[Zarf] ✅ محمي: ${participantNumber}`);
                    return false;
                }
                
                console.log(`[Zarf] ❌ سيتم طرد: ${participantNumber}`);
                return true;
            }).map(p => p.id);
            
            console.log(`[Zarf] عدد المطرودين: ${membersToRemove.length}`);

            // تنفيذ الطرد
            if (membersToRemove.length > 0) {
                const batchSize = 10;
                for (let i = 0; i < membersToRemove.length; i += batchSize) {
                    const batch = membersToRemove.slice(i, i + batchSize);
                    
                    // فحص أمان إضافي قبل الطرد
                    const safeBatch = batch.filter(member => {
                        const memberNumber = member.split('@')[0];
                        return !uniqueProtectedNumbers.includes(memberNumber);
                    });
                    
                    if (safeBatch.length > 0) {
                        await sock.groupParticipantsUpdate(jid, safeBatch, "remove");
                        safeBatch.forEach(member => addKicked([member]));
                    }
                    
                    if (i + batchSize < membersToRemove.length) {
                        await new Promise(resolve => setTimeout(resolve, 1000));
                    }
                }
                
                await sock.sendMessage(jid, { 
                    text: `✅ *تمت التصفية بنجاح!*\n\n👥 *عدد المطرودين:* ${membersToRemove.length}\n🛡️ *المتبقي:* المالك/البوت + النخبة فقط.`
                }, { quoted: m });
                
            } else {
                await sock.sendMessage(jid, { 
                    text: 'ℹ️ *لا يوجد أعضاء للطرد*\nالمجموعة تحتوي فقط على الأعضاء المحميين.'
                }, { quoted: m });
            }

            // الرسالة النهائية
            if (zarf.finalMessage?.status === 'on' && zarf.finalMessage.text) {
                setTimeout(async () => {
                    await sock.sendMessage(jid, { text: zarf.finalMessage.text }).catch(() => null);
                }, 2000);
            }

        } catch (err) {
            console.error('[Zarf Error]:', err.message);
            
            let errorMessage = '❌ *حدث خطأ أثناء التصفية*\n';
            if (err.message.includes('not a admin')) {
                errorMessage += 'البوت ليس مشرفاً في المجموعة. يرجى ترقية صلاحيات البوت أولاً.';
            } else {
                errorMessage += `الخطأ: ${err.message}`;
            }
            
            await sock.sendMessage(jid, { text: errorMessage }, { quoted: m });
        }
    }
};