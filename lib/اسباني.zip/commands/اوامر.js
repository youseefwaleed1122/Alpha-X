const { prepareWAMessageMedia, generateWAMessageFromContent } = require('@whiskeysockets/baileys');
const moment = require('moment-timezone');

// دالة حساب مدة النشاط
function getUptime() {
    const uptimeSeconds = process.uptime();
    const hours = Math.floor(uptimeSeconds / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);
    return `${hours}:${minutes}:${seconds}`;
}

module.exports = {
    name: 'اوامر',
    aliases: ['اوامر', 'قائمة', 'help'],
    description: 'قائمة الأوامر الرسمية لبوت 𝙀𝘽𝙉_𝙈𝘼𝙎𝙍〆#̷ᵃˢᵇᵃⁿʸ#̷〆',
    usage: '.اوامر',
    async execute(sock, m, a, ctx) {
        const { cmds, cfg } = ctx;
        const jid = m.key.remoteJid;

        // إعدادات الوقت والتاريخ (توقيت مكة المكرمة)
        const date = moment().tz('Asia/Riyadh').format('DD/MM/YYYY');
        const day = moment().tz('Asia/Riyadh').locale('ar').format('dddd');
        const uptimeStr = getUptime();

        // تفاعل الإيموجي
        await sock.sendMessage(jid, { react: { text: '🐲', key: m.key } });

        // تجهيز الصورة
        const media = await prepareWAMessageMedia(
            { image: { url: 'https://i.postimg.cc/h4wpGxn2/Asbany.jpg' } },
            { upload: sock.waUploadToServer }
        );

        // القالب الذي طلبته بالضبط
        const menuText = `> ━ ╼╃ ⌬〔 ~𝙀𝘽𝙉_𝙈𝘼𝙎𝙍〆~ 〕⌬ ╄╾ ━
> *┤────────────···*
> *┤ مرحبا بك في قائمة بوت إبْـــنِ مــَـصْــࢪّ*
> *┤────────────···*
> *✧────[ معلومات الـبـوت ]────╮*
> *┤ 🤖┊ اسم البوت: إبْـــنِ مــَـصْــࢪّ*
> *┤ ⚙️┊اصدار البوت: 2.2v*
> *┤ 🖲┊ البادئة: نقطة.*
> *┤ ♦┊ المهنة : زرف*
> *┤ 🌐┊الموقع الإلكتروني:*
https://kornos.online
> *┤────────────···* 
> *✧────[ الـوقـت ]────╮*
> *┤ 📆┊التاريخ: 19‏/3‏/2026*
> *┤ 🗓┊اليوم: الخميس*
> *┤ 🚀┊ النشاط: 0:52:30*
> *┤────────────···*

> *⋅ ───━ •﹝♦﹞• ━─── ⋅*`;

        // تجهيز الأزرار
        const buttons = [
            {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: '📜┇قائمة الأوامر┇📜',
                    sections: [
                        {
                            title: '📂 ┇ 𝐀𝐒𝐁𝐀𝐍𝐘 𝐁𝐎𝐓 𝐌𝐄𝐍𝐔 ┇ 📂',
                            rows: Array.from(cmds.values()).map(c => ({
                                header: `🔖 قسم: ${c.category || 'العام'}`,
                                title: `${cfg.prefix}${c.name}`,
                                description: c.description,
                                id: `${cfg.prefix}${c.name}`
                            }))
                        }
                    ]
                })
            },
       ];
        // بناء وإرسال الرسالة التفاعلية
        const msg = generateWAMessageFromContent(jid, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: { text: menuText },
                        footer: { text: `> 𝙱𝚈┇𝙰𝚂𝙱𝙰𝙽𝚈 𝙱𝙾𝚃` },
                        header: {
                            hasMediaAttachment: true,
                            imageMessage: media.imageMessage
                        },
                        nativeFlowMessage: {
                            buttons: buttons
                        }
                    }
                }
            }
        }, { quoted: m });

        await sock.relayMessage(jid, msg.message, { messageId: msg.key.id });
    }
};
