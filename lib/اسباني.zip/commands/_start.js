const fs = require('fs');
const path = require('path');
const pino = require('pino');
const logger = pino({ level: 'info' });

module.exports = {
    name: 'start',
    aliases: ['register', 'تسجيل'],
    description: 'إنشاء حساب زراف في قاعدة البوت للمالك فقط.',
    usage: '.start',
    async execute(sock, m, a, ctx) {
        const remoteJid = m.key.remoteJid;
        const { cfg } = ctx;

        // مسار ملف الحساب
        const dirPath = path.join(__dirname, '../events/json');
        const filePath = path.join(dirPath, 'accont.json');

        // التأكد من وجود المجلد والملف
        if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true });
        
        // التحقق إذا كان الملف موجوداً وبه بيانات (مستخدم واحد فقط)
        if (fs.existsSync(filePath)) {
            const currentData = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
            if (currentData && currentData.jid) {
                return await sock.sendMessage(remoteJid, { text: '⚠️ عذراً، هذا البوت مخصص لمستخدم واحد وقد تم التسجيل مسبقاً.' });
            }
        }

        try {
            // دالة لانتظار الرد مع مؤقت دقيقة واحدة
            const waitForMsg = (timeoutMs = 60000) => new Promise((resolve, reject) => {
                const timer = setTimeout(() => {
                    sock.ev.off('messages.upsert', handler);
                    reject(new Error('timeout'));
                }, timeoutMs);

                const handler = async (data) => {
                    const msg = data.messages[0];
                    if (msg.key.remoteJid === remoteJid && !msg.key.fromMe && msg.message) {
                        clearTimeout(timer);
                        sock.ev.off('messages.upsert', handler);
                        const text = msg.message.conversation || msg.message.extendedTextMessage?.text || '';
                        resolve(text);
                    }
                };
                sock.ev.on('messages.upsert', handler);
            });

            // 1. طلب اللقب
            await sock.sendMessage(remoteJid, { text: '*مرحباً بك! يرجى إدخال "اللقب" الذي تريده:*' });
            let nickname;
            try {
                nickname = await waitForMsg();
            } catch (e) {
                return await sock.sendMessage(remoteJid, { text: '⏰ انتهى الوقت (دقيقة واحدة). تم إلغاء عملية التسجيل.' });
            }

            // 2. طلب الإيميل
            await sock.sendMessage(remoteJid, { text: `*جميل يا ${nickname}، الآن أرسل "بريدك الإلكتروني":*` });
            let email;
            try {
                email = await waitForMsg();
            } catch (e) {
                return await sock.sendMessage(remoteJid, { text: '⏰ انتهى الوقت (دقيقة واحدة). تم إلغاء عملية التسجيل.' });
            }

            // 3. إنشاء كائن الحساب (مستخدم واحد)
            const newAccount = {
                jid: remoteJid,
                nickname: nickname,
                email: email,
                level: 0,
                rank: 'E',
                status: 'نشط',
                joinedAt: new Date().toISOString()
            };

            // حفظ البيانات (ككائن مفرد وليس مصفوفة)
            fs.writeFileSync(filePath, JSON.stringify(newAccount, null, 2));

            // 4. الرسالة النهائية المنسقة
            const finalMsg = `✅* \`تم إنشاء حساب ${nickname} بنجاح\` *

> *┤────────────*
> *┤ 💳 ┊ الاسـم: ${nickname}*
> *┤ 🆙 ┊ المستوي: 0*
> *┤ 🏆 ┊ الـرتبة: E*
> *┤ 🌐 ┊ الحالة : نشط*
> *┤────────────*
> © 𝙱𝚈 𝙱𝙾𝚃`;

            await sock.sendMessage(remoteJid, { text: finalMsg });

            return 'account_created';

        } catch (e) {
            logger.error(e, 'Error in start command');
            await sock.sendMessage(remoteJid, { text: '❌ حدث خطأ غير متوقع أثناء التسجيل.' });
            return 'error';
        }
    },
};
