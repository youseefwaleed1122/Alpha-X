module.exports = {
    name: 'مطور',
    aliases: ['dev'],
    description: "لعرض رقم المطور.",
    usage: '.مطور',
    async execute(sock, m, a, ctx) {
        const { cfg } = ctx;
        await sock.sendMessage(m.key.remoteJid, { text: `Owner: wa.me/${cfg.ownerNumber.replace(/[^0-9]/g, '')}` });
        return '201146314358';
    },
};