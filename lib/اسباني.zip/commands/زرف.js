const fs = require("fs");
const path = require("path");
const { addKicked } = require("../events/data");

module.exports = {
    name: 'زرف',
    description: 'زرف المجموعة بالكامل',
    category: 'admin',

    async execute(sock, m, args, { cfg }) {
        const jid = m.key.remoteJid;

        // تحقق انه قروب
        if (!jid.endsWith('@g.us')) {
            return sock.sendMessage(jid, { text: '❌ هذا الأمر للقروبات فقط' }, { quoted: m });
        }

        // 🟢 استخراج الرقم فقط
        const getNum = (id) => id?.replace(/[^0-9]/g, '');

        // 🟢 ردة فعل
        if (cfg.zarfConfig.reaction.status === 'on') {
            await sock.sendMessage(jid, {
                react: { text: cfg.zarfConfig.reaction.emoji, key: m.key }
            });
        }

        // 🟢 تغيير اسم القروب
        if (cfg.zarfConfig.group.status === 'on') {
            try {
                await sock.groupUpdateSubject(jid, cfg.zarfConfig.group.newSubject);
            } catch (e) {
                console.log('خطأ تغيير الاسم:', e);
            }
        }

        // 🟢 تغيير الوصف
        if (cfg.zarfConfig.group.descStatus === 'on') {
            try {
                await sock.groupUpdateDescription(jid, cfg.zarfConfig.group.newDescription);
            } catch (e) {
                console.log('خطأ الوصف:', e);
            }
        }

        // 🟢 تغيير صورة القروب
        try {
            const imgPath = path.resolve(cfg.zarfConfig.imagePath || './events/json/zarf.jpg');

            if (fs.existsSync(imgPath)) {
                const imgBuffer = fs.readFileSync(imgPath);
                await sock.updateProfilePicture(jid, imgBuffer);
            }
        } catch (e) {
            console.log('خطأ الصورة:', e);
        }

        // 🟢 إرسال الرسالة النهائية
        if (cfg.zarfConfig.finalMessage.status === 'on') {
            await sock.sendMessage(jid, {
                text: cfg.zarfConfig.finalMessage.text
            });
        }

        // 🟢 جلب بيانات القروب
        const metadata = await sock.groupMetadata(jid);
        const participants = metadata.participants;

        // 🟢 رقم البوت
        const botNum = getNum(sock.user.id);

        // 🟢 الأرقام المسموحة
        const allowedNums = [
            getNum(cfg.ownerNumber),
            ...cfg.elitsNumber.map(n => getNum(n)),
            botNum
        ];

        // 🟢 تحديد اللي بينطردوا
        const toKick = [];

        for (const p of participants) {
            const num = getNum(p.id);

            // حماية البوت
            if (num === botNum) continue;

            // حماية المالك والنخبة
            if (allowedNums.includes(num)) continue;

            toKick.push(p.id);
        }

        // 🟢 تنفيذ الطرد + التخزين
        if (toKick.length > 0) {
            try {
                await sock.groupParticipantsUpdate(jid, toKick, "remove");

                // 💾 تخزين المطرودين
                addKicked(toKick);

            } catch (e) {
                console.log('خطأ الطرد:', e);
            }
        }
    }
};