const { jidDecode } = require('@whiskeysockets/baileys');

const decode = jid => (jidDecode(jid)?.user || jid?.split('@')[0]) + '@s.whatsapp.net';

module.exports = {
    name: 'معرف',
    description: 'Get the WhatsApp ID of a mentioned user, number, or replied message',
    usage: '.معرف / .lid [mention | number | reply]',
    category: 'General',

    async execute(sock, msg, args) {
        try {
            const groupJid = msg.key.remoteJid;
            const sender = decode(msg.key.participant || msg.key.remoteJid);
            let targetJid;

            const contextInfo = msg.message?.extendedTextMessage?.contextInfo || {};
            const mentionedJid = contextInfo.mentionedJid;
            const quotedParticipant = contextInfo.participant;

            if (Array.isArray(mentionedJid) && mentionedJid.length > 0) {
                targetJid = mentionedJid[0];
            } else if (args?.[0]) {
                const cleaned = args[0].replace(/\D/g, '');
                if (!cleaned) throw new Error('❌ No valid number was specified.');
                targetJid = `${cleaned}@s.whatsapp.net`;
            } else if (quotedParticipant) {
                targetJid = decode(quotedParticipant);
            } else {
                targetJid = sender;
            }

            const number = targetJid.split('@')[0];

            await sock.sendMessage(groupJid, {
                text: number
            }, { quoted: msg });

        } catch (error) {
            console.error('✗ Error in id command:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: `❌ An error occurred while fetching the ID:\n${error.message || error.toString()}`
            }, { quoted: msg });
        }
    }
};