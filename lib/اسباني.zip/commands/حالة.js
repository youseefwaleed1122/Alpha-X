module.exports = {
    name: 'حالة',
    aliases: [],
    description: 'لعرض حالة البوت والبيغ.',
    usage: '.حالة',
    async execute(sock, msg, args, info) {
        const start = Date.now();
        await sock.sendMessage(msg.key.remoteJid, { text: 'Pong!' });
        const latency = Date.now() - start;
        await sock.sendMessage(msg.key.remoteJid, { text: `Latency: ${latency}ms` });
        return 'pong';
    },
}; 