const fs = require('fs');
const path = require('path');
const { getUniqueKicked } = require('../events/data'); // استدعاء ملف البيانات المشفرة

module.exports = {
    name: 'حسابي',
    aliases: ['بروفايل', 'profile'],
    description: 'عرض بيانات حسابك وإحصائيات المزروفين.',
    usage: '.حسابي',
    async execute(sock, m, a, ctx) {
        const remoteJid = m.key.remoteJid;
        const sender = m.key.participant || m.key.remoteJid;
        const filePath = path.join(__dirname, '../events/json/accont.json');

        // 1. التحقق من وجود حساب مسجل
        if (!fs.existsSync(filePath)) {
            return await sock.sendMessage(remoteJid, { text: '⚠️ لم تقم بإنشاء حساب بعد، استخدم أمر !start' });
        }

        const account = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
        
        if (account.jid !== sender && !sender.includes(account.jid.split('@')[0])) {
            // تجاهل (نفس منطقك)
        }

        // 2. جلب الإحصائيات
        const kickedMap = getUniqueKicked();
        const totalKicked = kickedMap.size;

        // 3. حساب المستوى
        const level = Math.floor(totalKicked / 5);

        // 4. تحديد الرتبة
        let rank = 'E';
        if (level >= 0 && level < 10) rank = 'E';
        else if (level >= 10 && level < 25) rank = 'D';
        else if (level >= 25 && level < 45) rank = 'C';
        else if (level >= 45 && level < 70) rank = 'B';
        else if (level >= 70 && level < 100) rank = 'A';
        else if (level >= 100 && level < 135) rank = 'S';
        else if (level >= 135 && level < 175) rank = 'S+';
        else if (level >= 175 && level < 220) rank = 'SS+';
        else if (level >= 220) rank = 'SSS+';

        // 5. الرسالة النهائية
        const status = "نشط";
        const response = `> *✧────[ \`الحــسـاب\` ]────╮*
> *┤ 💳 ┊ الاسـم: ${account.nickname}*
> *┤ 🆙 ┊ المستوي: ${level}*
> *┤ 🏆 ┊الـرتبة: ${rank}*
> *┤ 🌐 ┊الحالة: ${status}*
> *┤────────────···*
> *✧────[ \`المزروفين\` ]────╮*
> *┤ 👤┊عدد الأعضاء: ${totalKicked}*
> *┤────────────···*
> © 𝙱𝚈 𝙰𝚂𝙱𝙰𝙽𝚈 𝙱𝙾𝚃`;

        await sock.sendMessage(remoteJid, { text: response });
        return 'profile_success';
    }
};