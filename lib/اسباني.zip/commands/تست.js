module.exports = {
  name: 'تست',
  description: 'Check if the bot is working',
  usage: '.test',
  category: 'General',

  execute: async (sock, msg, args) => {
    try {
      const jid = msg.key.remoteJid;

      const caption = `
*❍━━══━━✦🌊✦━━══━━❍*
*┊    🚀『 𝐀𝐒𝐁𝐀𝐍𝐘 』🚀 ┊*
*❍━━══━━✦🌊✦━━══━━❍*

*『 👨‍💻 | Bot Info 』*
╭─────────────⟢  
│ *🤖 Name:*  𝐀𝐒𝐁𝐀𝐍𝐘
│ *⚙️ Version:* v2.2
│ *👤 Developer:* +201146314358
╰─────────────⟢

*❍━━══━━❪ 🚀 ❫━━══━━❍*
✅ *𝐀𝐒𝐁𝐀𝐍𝐘 𝐁𝐨𝐭 𝐖𝐨𝐫𝐤𝐢𝐧𝐠*
*❍━━══━━❪ 🚀 ❫━━══━━❍*
      `.trim();

      await sock.sendMessage(jid, {
        text: caption,
        contextInfo: {
          externalAdReply: {
            thumbnailUrl: "https://i.postimg.cc/26n3kh69/Asbany.jpg"
            // no sourceUrl
          }
        }
      }, { quoted: msg });

    } catch (error) {
      console.error('❌ Error while executing test command:', error);
      await sock.sendMessage(jid, { text: '❌ An error occurred while executing the command.' }, { quoted: msg });
    }
  }
};