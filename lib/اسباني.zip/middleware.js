const pino = require('pino');
const logger = pino({ level: 'info' });

const pre = [
    async (m, ctx) => {
        const sender = m.key.remoteJid;
        const text = m.message?.conversation || '';

        // تسجيل الحدث بشكل احترافي
        logger.info({ sender, text }, 'Incoming Message');
        
        return true;
    }
];

const post = [
    async (m, ctx, res) => {
        logger.info({ status: res }, 'Command Processed');
    }
];

module.exports = { pre, post };
