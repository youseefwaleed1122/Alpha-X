const { default: Auth, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, makeCacheableSignalKeyStore } = require('@whiskeysockets/baileys');
const { say } = require('cfonts'); 
const pino = require('pino');
const fs = require('fs');
const path = require('path');
const readline = require('readline'); // لإدخال رقم الهاتف من التيرمينال
const cfg = require('./config');

const question = (text) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    return new Promise((resolve) => rl.question(text, (ans) => { rl.close(); resolve(ans); }));
};

// Welcome Banner
say(cfg.botName || 'EMS BOT', {
    font: 'block',
    align: 'center',
    colors: ['cyan', 'blue'],
    space: true,
});

const cmds = new Map(), als = new Map(), evs = new Map(), pre = [], post = [];

// تحميل الأوامر والأحداث (نفس كودك السابق)
const cPath = path.join(__dirname, 'commands');
if (fs.existsSync(cPath)) {
    fs.readdirSync(cPath).forEach(f => {
        if (f.endsWith('.js')) {
            const cmd = require(path.join(cPath, f));
            cmds.set(cmd.name, cmd);
            if (cmd.aliases) cmd.aliases.forEach(a => als.set(a, cmd.name));
        }
    });
}
const ePath = path.join(__dirname, 'events');
if (fs.existsSync(ePath)) {
    fs.readdirSync(ePath).forEach(f => {
        if (f.endsWith('.js')) {
            const ev = require(path.join(ePath, f));
            evs.set(ev.event, ev.handler);
        }
    });
}

async function Go() {
    const { state, saveCreds } = await useMultiFileAuthState(cfg.sessionPath);
    const { version } = await fetchLatestBaileysVersion();
    
    const sock = Auth({
        version,
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' })),
        },
        printQRInTerminal: false, // سنعطله لأننا سنستخدم Pairing Code
        logger: pino({ level: 'silent' }),
        syncFullHistory: false,
    });

    // الجزء المسؤول عن طلب رقم الهاتف وتوليد الكود
    if (!sock.authState.creds.registered) {
        const phoneNumber = await question('أدخل رقم هاتف البوت مع رمز الدولة (مثال: 9665xxxxx):\n');
        const code = await sock.requestPairingCode(phoneNumber.trim());
        console.log(`\nكود الربط الخاص بك هو: ${code}\n`);
    }

    sock.ev.on('creds.update', saveCreds);

    for (const [ev, fn] of evs) {
        sock.ev.on(ev, (...a) => fn(sock, ...a, { cmds, als, cfg, pre, post }));
    }

    sock.ev.on('connection.update', ({ connection, lastDisconnect }) => {
        if (connection === 'close') {
            const again = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            if (again) Go();
        } else if (connection === 'open') {
            console.log('--- Bot is online! ---');
        }
    });
}

Go().catch(e => console.error('Failed to start bot:', e));
