const pino = require('pino');
const logger = pino({ level: 'info' });

module.exports = {
    event: 'messages.upsert',
    handler: async (sock, data, ctx) => {
        try {
            const m = data.messages && data.messages[0];
            if (!m || !m.message || m.key.fromMe) return;

            const { cmds, als, cfg, pre, post } = ctx;
            
            const txt = m.message.conversation || m.message.extendedTextMessage?.text || '';
            
            // قائمة الرموز المسموح بها
            const prefixes = ['.', ',', '؟', '$', '^', '°', '\\', '/', '*', '•', '&', '+', '-'];
            
            // التحقق إذا كان النص يبدأ بأي من هذه الرموز
            const usedPrefix = prefixes.find(p => txt.startsWith(p));
            
            // إذا لم يبدأ النص بأي رمز مسموح، يتم التجاهل
            if (!usedPrefix) return;

            // تحليل الأمر بناءً على الرمز المكتشف (إزالة طول الرمز المستخدم)
            const a = txt.slice(usedPrefix.length).trim().split(/\s+/);
            const cmd = a.shift().toLowerCase();
            const key = cmds.has(cmd) ? cmd : als.get(cmd);

            if (!key || !cmds.has(key)) return;

            // تشغيل الميدل وير (Pre-processing)
            for (const fn of pre) {
                const go = await fn(m, ctx);
                if (!go) return;
            }

            const c = cmds.get(key);
            let res;

            try {
                res = await c.execute(sock, m, a, { ...ctx, command: c });
            } catch (e) {
                logger.error({ command: cmd, error: e.message }, 'Command Execution Failed');
                await sock.sendMessage(m.key.remoteJid, { text: `❌ Error: ${e.message}` });
                res = 'error';
            }

            for (const fn of post) {
                await fn(m, ctx, res);
            }

        } catch (e) {
            logger.error({ error: e.message }, 'Error in messages.upsert event');
        }
    }
};
