const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// إعداد المسارات داخل مجلد json كما طلبت
const jsonDir = path.join(__dirname, 'json');
const filePath = path.join(jsonDir, 'data.json');

// ملفات التشفير داخل مجلد json أيضاً
const legacyEncPath = path.join(jsonDir, 'enc');
const newEncPath = path.join(jsonDir, 'enc1');
const encPath = fs.existsSync(legacyEncPath) ? legacyEncPath : newEncPath;

// التأكد من وجود المجلد
if (!fs.existsSync(jsonDir)) {
    fs.mkdirSync(jsonDir, { recursive: true });
}

/**
 * الحصول على مفتاح التشفير أو إنشاؤه
 */
function getSecret() {
    try {
        let pass = "";
        if (!fs.existsSync(encPath)) {
            pass = crypto.randomBytes(16).toString('hex');
            fs.writeFileSync(encPath, pass, 'utf8');
            // استخدمنا console.log العادي لتجنب تعارض pino هنا أثناء التهيئة
            console.log(`[Security] Key file created: ${path.basename(encPath)}`);
        } else {
            pass = fs.readFileSync(encPath, 'utf-8').trim();
            if (!pass) {
                pass = crypto.randomBytes(16).toString('hex');
                fs.writeFileSync(encPath, pass, 'utf8');
            }
        }
        return crypto.createHash('sha256').update(pass).digest();
    } catch (e) {
        console.error("Critical Error accessing encryption key:", e);
        return crypto.createHash('sha256').update('EMERGENCY_KEY').digest();
    }
}

/**
 * إعادة ضبط الملف عند كشف تلاعب
 */
function resetAndWarn(reason) {
    console.error('\n' + '!'.repeat(50));
    console.error(`[SECURITY ALERT] Tampering detected in data.json!`);
    console.error(`[REASON] ${reason}`);
    console.error(`[ACTION] File has been reset.`);
    console.error('!'.repeat(50) + '\n');
    
    fs.writeFileSync(filePath, JSON.stringify({}));
    return new Map();
}

const iv = Buffer.alloc(16, 0);

// وظائف التشفير الأساسية
function encryptText(text, secret) {
    const cipher = crypto.createCipheriv('aes-256-ctr', secret, iv);
    return Buffer.concat([cipher.update(text.toString()), cipher.final()]).toString('hex');
}

function decryptText(encrypted, secret) {
    const decipher = crypto.createDecipheriv('aes-256-ctr', secret, iv);
    return Buffer.concat([
        decipher.update(Buffer.from(encrypted, 'hex')),
        decipher.final()
    ]).toString();
}

/**
 * حفظ البيانات المشفرة
 */
function saveUniqueMap(map, secret) {
    const obj = {};
    for (const [id, timestamp] of map.entries()) {
        const cleanId = id.toString().split('@')[0];
        const encryptedKey = encryptText(cleanId, secret);
        const encryptedValue = encryptText(timestamp.toString(), secret);
        obj[encryptedKey] = encryptedValue;
    }
    fs.writeFileSync(filePath, JSON.stringify(obj));
}

// تصدير الوظائف بنظام CommonJS
module.exports = {
    encrypt: (data) => {
        const cleanData = data.toString().split('@')[0];
        return encryptText(cleanData, getSecret());
    },

    decrypt: (encrypted, secretOverride = null) => {
        try {
            const secret = secretOverride || getSecret();
            return decryptText(encrypted, secret);
        } catch (e) {
            throw new Error("Decryption Failed");
        }
    },

    getUniqueKicked: () => {
        if (!fs.existsSync(filePath)) return new Map();

        let json;
        try {
            const raw = fs.readFileSync(filePath, 'utf-8');
            json = JSON.parse(raw);
        } catch (e) {
            return resetAndWarn("Invalid JSON format");
        }

        const secret = getSecret();
        const dataMap = new Map();
        const entries = Object.entries(json);

        for (const [encKey, encValue] of entries) {
            try {
                const idVal = decryptText(encKey, secret);
                
                // تحقق من سلامة البيانات (IDs)
                if (!/^\d+$/.test(idVal)) return resetAndWarn("Non-numeric ID detected.");
                if (idVal.length < 10 || idVal.length > 20) return resetAndWarn("Invalid ID length.");

                const timeValStr = decryptText(encValue, secret);
                const timeVal = parseInt(timeValStr, 10);

                if (isNaN(timeVal)) return resetAndWarn("Invalid timestamp.");
                
                const now = Date.now();
                if (timeVal > now + 60000) return resetAndWarn("Future timestamp detected.");

                dataMap.set(idVal + '@lid', timeVal);
            } catch (e) {
                return resetAndWarn("Decryption failed / Data manipulation");
            }
        }
        return dataMap;
    },

    addKicked: (ids) => {
        const currentMap = module.exports.getUniqueKicked();
        let changed = false;
        const now = Date.now();

        ids.forEach(id => {
            const cleanId = id.toString().split('@')[0];
            const lidFormat = cleanId + '@lid';
            if (cleanId.length >= 10) {
                if (!currentMap.has(lidFormat)) {
                    currentMap.set(lidFormat, now);
                    changed = true;
                }
            }
        });

        if (changed) {
            saveUniqueMap(currentMap, getSecret());
        }
        return currentMap.size;
    },

    updateEncryptionPassword: (newPassword) => {
        try {
            const currentMap = module.exports.getUniqueKicked();
            fs.writeFileSync(encPath, newPassword, 'utf8');
            const newSecret = crypto.createHash('sha256').update(newPassword).digest();
            saveUniqueMap(currentMap, newSecret);
            return true;
        } catch (e) {
            console.error("Failed to rotate password:", e);
            return false;
        }
    }
};
