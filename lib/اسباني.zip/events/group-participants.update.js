const pino = require('pino');
const logger = pino({ level: 'info' });

module.exports = {
    event: 'group-participants.update',
    handler: async (sock, up, ctx) => {
        try {
            const { id, participants, action } = up;

            // تسجيل الحدث باستخدام pino بدلاً من chalk
            logger.info({ 
                group: id, 
                action: action, 
                users: participants 
            }, 'Group participants updated');

            if (action === 'add') {
                for (const u of participants) {
                    await sock.sendMessage(id, { 
                        text: `Welcome @${u.split('@')[0]}!`, 
                        mentions: [u] 
                    });
                }
            }
        } catch (e) {
            // تسجيل الخطأ بشكل منظم
            logger.error({ err: e.message, group: up.id }, 'Error in group-participants.update');
        }
    }
};
