module.exports = {
    ownerNumber: '201024192903@s.whatsapp.net', 
    botNumber: '201024192903@s.whatsapp.net', // ⚠️ ضع رقم البوت الحقيقي هنا (وليس رقمك)
    elitsNumber: [
        '201024192903@s.whatsapp.net'  // رقمك أنت كمالك/نخبة
        // يمكنك إضافة أرقام نخبة أخرى هنا
    ],
    prefix: '.',
    botName: '𝘼𝙎𝙋𝘼𝙉𝙔ـ𓁻 MD',
    sessionPath: './session',
    
    // إعدادات الزرف
    zarfConfig: {
        reaction: {
            status: `on`,
            emoji: `🫦`
        },
        group: {
            status: `on`,
            descStatus: `on`,
            newSubject: `*⌬〔 ~𝙀𝘽𝙉_𝙈𝘼𝙎𝙍 𝐁𝐎𝐓~ 〕⌬*\n*┤────────────···*\n*┤❐┊تم فشخكم من قبل حاكم المجال 𝘼𝙎𝙋𝘼𝙉𝙔ءالحاكم  زراف『🐉』"*\n*┤────────────···*\n*┤❐┊راح ينزل الزرف في البار خش واعرف كيف انزرفت『🤪』"*\n\n*باࢪ اسـباني الحاكم*\n~https://chat.whatsapp.com/Ft7UeE38D5B5IcI4GjZ2Az?mode=gi_t~\n*┤────────────···*\n*┤❐┊ روابط مهمة*\n\n𝐘𝐨𝐮 𝐠𝐨𝐭 𝐫𝐢𝐩𝐩𝐞𝐝 𝐭𝐨 𝐬𝐡𝐫𝐞𝐝𝐬 𝐛𝐲: 𝐀𝐒𝐁𝐀𝐍𝐘.`
        },
        finalMessage: {
            status: `on`,
            text: `*⌬〔 ~𝐀𝐒𝐁𝐀𝐍𝐘 𝐁𝐎𝐓~ 〕⌬*\n\n*❐ تم الزرف تحت قدم ﴿ أسـبــانـي *\n\nتبي تعرف كيف انزرفت؟ 👀  \nالجواب هنا:\n\n*𝙀. 𝙎. 𝙋. 𝘼. 𝙉. 𝙔 {〠} بــ♘اࢪ*\n~https://chat.whatsapp.com/Ft7UeE38D5B5IcI4GjZ2Az?mode=gi_t~\n\nــــــــــــــــــــــــــــــــــــــــــــــــ\n𝐘𝐨𝐮 𝐠𝐨𝐭 𝐫𝐢𝐩𝐩𝐞𝐝 𝐭𝐨 𝐬𝐡𝐫𝐞𝐝𝐬 𝐛𝐲: 𝐀𝐒𝐁𝐀𝐍𝐘.`
        }
    }
};